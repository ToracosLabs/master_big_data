readFile <- read.csv("/home/toracoslabs/Escritorio/anexos/distribucion_invocadores/salida.csv")

#install.packages('plyr')
library(plyr)


df <- count(readFile, 'Liga')
total_rows = nrow(total_rows)

# Frecuencia total
p<-ggplot(data=df, aes(
  x=c(
    "CHALLENGER I",
    "GRANDMASTER I", 
    "MASTER I", 
    "DIAMOND I", "DIAMOND II", "DIAMOND III", "DIAMOND VI", 
    "PLATINUM I", "PLATINUM II","PLATINUM III","PLATINUM VI",
    "GOLD I", "GOLD II", "GOLD III", "GOLD VI", 
    "SILVER I", "SILVER II", "SILVER III", "SILVER VI", 
    "BRONZE I", "BRONZE II", "BRONZE III", "BRONZE VI", 
    "IRON I","IRON II","IRON III","IRON VI"
), y=freq)) +
  geom_bar(stat="identity") 

# Frecuencia relativa


p<-ggplot(data=df, aes(
  x=c(
    "CHALLENGER I",
    "GRANDMASTER I", 
    "MASTER I", 
    "DIAMOND I", "DIAMOND II", "DIAMOND III", "DIAMOND VI", 
    "PLATINUM I", "PLATINUM II","PLATINUM III","PLATINUM VI",
    "GOLD I", "GOLD II", "GOLD III", "GOLD VI", 
    "SILVER I", "SILVER II", "SILVER III", "SILVER VI", 
    "BRONZE I", "BRONZE II", "BRONZE III", "BRONZE VI", 
    "IRON I","IRON II","IRON III","IRON VI"
  ), y=(freq*100) / total_rows  )) +
  geom_bar(stat="identity") 

p + coord_flip()
