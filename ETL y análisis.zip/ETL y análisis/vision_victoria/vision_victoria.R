df <- read.csv("/home/toracoslabs/Escritorio/anexos/vision_victoria/vision_matches_liga.csv")

df$sum_wards <- df$wardsPlaced_1 + df$wardsPlaced_2 + df$wardsPlaced_3 + df$wardsPlaced_4 + df$wardsPlaced_5 + df$wardsPlaced_6 + df$wardsPlaced_7 + df$wardsPlaced_8 + df$wardsPlaced_9 + df$wardsPlaced_10 
df$dif_wards <- (df$wardsPlaced_1 + df$wardsPlaced_2 + df$wardsPlaced_3 + df$wardsPlaced_4 + df$wardsPlaced_5) - (df$wardsPlaced_6 + df$wardsPlaced_7 + df$wardsPlaced_8 + df$wardsPlaced_9 + df$wardsPlaced_10)
df$med_wards <- df$sum_wards/10

ggplot(df, aes(reorder(tier,sum_wards), sum_wards)) +           # ggplot2 barplot with mean
  geom_bar(position = "dodge",
           stat = "summary",
           fun = "mean")


ggplot(df, aes(reorder(victoria_azul,dif_wards), dif_wards)) +           # ggplot2 barplot with mean
  geom_bar(position = "dodge",
           stat = "summary",
           fun = "mean")