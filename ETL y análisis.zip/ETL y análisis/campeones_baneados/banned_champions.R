readFile <- read.csv("/home/toracoslabs/Escritorio/anexos/campeones_baneados/banned_champions.csv")

library(plyr)

df <- count(readFile, 'name')

p<-ggplot(data=df, aes(
  reorder(name,freq), y=freq)) +
  geom_bar(stat="identity") + coord_flip()

p


df <- read.csv("/home/toracoslabs/Escritorio/anexos/campeones_baneados/victoria_baneados.csv")

p <- ggplot(df, aes(name, ..count..)) + geom_bar(aes(fill = victory), position = "dodge")

p


