# Importamos librerías
import requests
import pymongo
import json
from json import JSONEncoder
import time
from datetime import datetime

url = "http://ddragon.leagueoflegends.com/cdn/12.1.1/data/en_US/item.json"
response = requests.get(url)
response = response.json()

items = response["data"]
myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["lolmaster"]
itemsTable = mydb["items"]

for item in items: 
    item_json = items[item]
    i_name = item_json["name"]
    i_id = item
    print("name: " + i_name + " id: " + i_id)
    #Configuramos el cliente Mongo
    itemsTable.insert_one({"id": i_id, "name":i_name})
    print("inserted")