# Importamos librerías
import requests
import pymongo
import json
from json import JSONEncoder
import time
from datetime import datetime

url = "http://ddragon.leagueoflegends.com/cdn/12.1.1/data/en_US/champion.json"
response = requests.get(url)
response = response.json()

champions = response["data"]
myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["lolmaster"]
championsTable = mydb["champions"]

for champion in champions: 
    champion_json = champions[champion]
    c_name = champion_json["name"]
    c_id = champion_json["key"]
    print("name: " + c_name + " id: " + c_id)
    #Configuramos el cliente Mongo
    championsTable.insert_one({"id": c_id, "name":c_name})
    print("inserted")