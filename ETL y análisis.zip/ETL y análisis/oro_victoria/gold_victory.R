df <- read.csv("/home/toracoslabs/Escritorio/anexos/oro_victoria/gold_matches_liga.csv")

df$sum_gold <- df$goldEarned_1 + df$goldEarned_2 + df$goldEarned_3 + df$goldEarned_4 + df$goldEarned_5 + df$goldEarned_6 + df$goldEarned_7 + df$goldEarned_8 + df$goldEarned_9 + df$goldEarned_10 
df$dif_gold <- (df$goldEarned_1 + df$goldEarned_2 + df$goldEarned_3 + df$goldEarned_4 + df$goldEarned_5) - (df$goldEarned_6 + df$goldEarned_7 + df$goldEarned_8 + df$goldEarned_9 + df$goldEarned_10 )
df$med_gold <- df$sum_gold/10

ggplot(df, aes(reorder(tier,sum_gold), sum_gold)) +           # ggplot2 barplot with mean
  geom_bar(position = "dodge",
           stat = "summary",
           fun = "mean")


ggplot(df, aes(reorder(victoria_azul,dif_gold), dif_gold)) +           # ggplot2 barplot with mean
  geom_bar(position = "dodge",
           stat = "summary",
           fun = "mean")