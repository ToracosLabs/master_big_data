# Importamos librerías
import requests
import pymongo
import json
from json import JSONEncoder
import time
from datetime import datetime

# Definimos la APIKey
apiKey = "--"

# Límite de tiempo
lastCheck = datetime.now()
numRequest = 0

#Configuramos el cliente Mongo
myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["lolmaster"]

def checkRateLimit():
    global lastCheck
    global numRequest

    timeNow = datetime.now()
    timeDiff = (timeNow - lastCheck)
    timeDiff = timeDiff.total_seconds()/60

    print("Testing API limits...")
    print("Diff: " + str(timeDiff))
    print(numRequest)

    if timeDiff < 2 and numRequest >= 95:
        print("Limit reached, sleeping...")
        time.sleep(120)
        numRequest = 0
    
    lastCheck = datetime.now()
    return 1

def getUnanalysedSummoner():
    global numRequest
    #Cargamos usuario no analizado
    summonersIdTable = mydb["summonerid"]
    summoner = summonersIdTable.find_one({ "analysed": 0 })
    summonerId = summoner["id"]
    return summonerId

def getUnanalysedMatch():
    global numRequest
    #Cargamos usuario no analizado
    matchesIdTable = mydb["matchesid"]
    match = matchesIdTable.find_one({ "timeline_analysed": 0 })
    matchId = match["id"]
    return matchId

def setAnalized(summonerId):
    global numRequest
    summonersIdTable = mydb["summonerid"]
    summonersIdTable.update_one({"id": summonerId},{"$set": { "analysed":1 }})
    return 1

def setTimelineAnalized(matchId):
    global numRequest
    matchesIdTable = mydb["matchesid"]
    matchesIdTable.update_one({"id": matchId},{"$set": { "timeline_analysed":1 }})
    return 1

def insertSummoner(summonerId):
    global numRequest

    #Comprobamos si existe ya el usuario en la BBDD
    summonersTable = mydb["summoner"]
    summonerCount = summonersTable.count_documents({"id":summonerId})

    if summonerCount == 0:
        checkRateLimit()
        numRequest = numRequest + 1
        url = "https://euw1.api.riotgames.com/lol/summoner/v4/summoners/" + summonerId + "?api_key=" + apiKey
        response = requests.get(url)
        response = response.json()
        print("Inserting Summoner with id: " + summonerId)
        summonersTable.insert_one(response)
        print("Inserted")
    else:
        print("Summoner already inserted")
    return 1

def insertTimeline(matchId):
    global numRequest

    #Comprobamos si existe ya el match en la BBDD
    matchTimelineTable = mydb["match_timeline"]
    matchTimelineTableCount = matchTimelineTable.count_documents({"matchId":matchId})

    if matchTimelineTableCount == 0:
        checkRateLimit()
        numRequest = numRequest + 1
        url = "https://europe.api.riotgames.com/lol/match/v5/matches/" + matchId + "/timeline?api_key=" + apiKey
        response = requests.get(url)
        response = response.json()
        print("Inserting MachTimeline with id: " + matchId)
        matchTimelineTable.insert_one({"matchId": matchId,"timeline":response} )
        print("Inserted")
        setTimelineAnalized(matchId)
    else:
        print("Match Timeline already inserted")
    return 1


def insertSummonerLeague(summonerId):
    global numRequest

    #Comprobamos si existe ya el usuario en la BBDD
    summonersTable = mydb["summonerleague"]
    summonerCount = summonersTable.count_documents({"summonerId":summonerId})

    if summonerCount == 0:
        checkRateLimit()
        numRequest = numRequest + 1
        url = "https://euw1.api.riotgames.com/lol/league/v4/entries/by-summoner/" + summonerId + "?api_key=" + apiKey
        response = requests.get(url)
        response = response.json()
        print("Inserting Summoner League with id: " + summonerId)
        summonersTable.insert_one({"summonerId": summonerId, "ranks": response })
        print("Inserted")
    else:
        print("Summoner league already inserted")
    return 1

def getPuuid(summonerId):
    global numRequest

    summonersTable = mydb["summoner"]
    print("Getting puuid of summoner with id: " + summonerId)
    result = summonersTable.find_one({"id":summonerId})
    summonerPuuid = result["puuid"] 
    print("Done: " + summonerPuuid)
    return summonerPuuid

def insertMatches(summonerPuuid):
    global numRequest

    matchesIdTable = mydb["matchesid"]
    matchesTable = mydb["matches"]
    summonersIdTable = mydb["summonerid"]
    summonersTable = mydb["summoner"] 
    checkRateLimit()
    numRequest = numRequest + 1
    print("Getting matches...")
    url = "https://europe.api.riotgames.com/lol/match/v5/matches/by-puuid/" + summonerPuuid + "/ids?type=ranked&start=0&count=100&api_key=" + apiKey
    response = requests.get(url)
    response = response.json()
    for matchId in response:
        matchCount = matchesIdTable.count_documents({"id":matchId})
        if matchCount == 0:
            matchesIdTable.insert_one({"id": matchId, "analysed": 0 })
            checkRateLimit()
            numRequest = numRequest + 1
            url = "https://europe.api.riotgames.com/lol/match/v5/matches/" + matchId + "?api_key=" + apiKey
            matchResponse = requests.get(url)
            matchResponse = matchResponse.json()
            matchesTable.insert_one(matchResponse)

            matchSummoners = matchResponse["metadata"]["participants"]
            for summoner in matchSummoners: 
                summonerCount = summonersIdTable.count_documents({"puuid": summoner})
                if summonerCount == 0:
                    checkRateLimit()
                    numRequest = numRequest + 1
                    summonerUrl = "https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-puuid/" + summoner + "?api_key=" + apiKey
                    summonerResponse = requests.get(summonerUrl)
                    summonerResponse = summonerResponse.json()
                    print(summonerResponse)
                    summonersTable.insert_one(summonerResponse)
                    summonersIdTable.insert_one({"puuid": summoner,"id": summonerResponse["id"] , "analysed": 0})
        else:
            print("Match already registered: " + matchId)
    return 1
            
while True:
   # summonerId = getUnanalysedSummoner()
   # insertSummoner(summonerId)
   # insertSummonerLeague(summonerId)
   # summonerPuuid = getPuuid(summonerId)
   # insertMatches(summonerPuuid)
   # setAnalized(summonerId)
   
   matchId = getUnanalysedMatch()
   insertTimeline(matchId)


