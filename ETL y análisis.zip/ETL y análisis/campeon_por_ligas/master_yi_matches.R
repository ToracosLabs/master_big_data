df <- read.csv("/home/toracoslabs/Escritorio/anexos/campeon_por_ligas/master_yi_matches.csv")

library(plyr)

df <- count(df, 'tier')

p<-ggplot(data=df, aes(
  reorder(tier,freq), y=(freq/sum(freq)))) +
  geom_bar(stat="identity") + coord_flip()

p



df <- read.csv("/home/toracoslabs/Escritorio/anexos/campeon_por_ligas/master_yi_matches.csv")
p <- ggplot(df, aes(tier, ..count..)) + geom_bar(aes(fill = victory), position = "dodge")
p