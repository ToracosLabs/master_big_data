readFile <- read.csv("/home/toracoslabs/Escritorio/anexos/enfrentamiento_entre_campeones/renek_enemies_matches.csv")

p <- ggplot(readFile, aes(name, ..count..)) + geom_bar(aes(fill = result), position = "dodge")
p