library(ggplot2)

df <- data.frame(
  Equipo = c("Rojo","Azul"),
  Valor = c(12721, 13081)
)

bp <- ggplot(df, aes(x="", y=Valor, fill=Equipo))+
  geom_bar(width = 1, stat = "identity")

pie <- bp + coord_polar("y", start=0)
pie
